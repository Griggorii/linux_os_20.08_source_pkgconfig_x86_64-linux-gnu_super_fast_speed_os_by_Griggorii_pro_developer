#!/bin/sh
export QT_STYLE_OVERRIDE=gtk
